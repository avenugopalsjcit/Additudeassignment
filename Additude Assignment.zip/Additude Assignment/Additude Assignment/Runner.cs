﻿using Additude_Assignment.Interfaces;

namespace Additude_Assignment
{
    public class Runner
    {
        private readonly IWordFrequency _wordFreqquency;
        private readonly ITextStatistics _textStatisticsFreq;
        public Runner(IWordFrequency wordFreq, ITextStatistics textStaticsFreq)
        {
            _wordFreqquency = wordFreq;
            _textStatisticsFreq = textStaticsFreq;
        }

        public void Run()
        {
            Additude additude = new Additude();
            additude.Startpoint();
           
        }
    }
}
