﻿// See https://aka.ms/new-console-template for more information

using Additude_Assignment.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System.Text.RegularExpressions;

namespace Additude_Assignment
{
    class Program
    {/// <summary>
    /// main function
    /// </summary>
    /// <param name="args"></param>
        static void Main(string[] args)
        {
            IServiceCollection services = new ServiceCollection();

            Startup startup = new Startup();
            startup.ConfigureServices(services);

            IServiceProvider serviceProvider = services.BuildServiceProvider();

            // entry to run app
            serviceProvider.GetService<Runner>().Run();
        }
    }

  /// <summary>
  /// Attitude class which implements interfaces.
  /// </summary>
    public class Additude : IWordFrequency, ITextStatistics
    {
        public void Startpoint()
        {
            int option;
            string text;
            Console.WriteLine("LIST OF OPERATIONS");
            Console.WriteLine("1: CountNumber of Lines in text");
            Console.WriteLine("2: Count most frequent list of words in text");
            Console.WriteLine("3: Count Longest words in text");
            Console.WriteLine("4: Total no. of words in text");
            Console.WriteLine("Please enter the option as a Integer");
            option = Convert.ToInt32(Console.ReadLine());
            if (option == 1)
            {  
                countNumberoflines();
                Console.ReadLine();
                callRun();

            }
            else if (option == 2)
            {
                Console.WriteLine("Enter number of frequent words to be displayed.");
                int count = Convert.ToInt32(Console.ReadLine());
                topFrequentlistWords(count);
                Console.ReadLine();
                callRun();
            }
            else if (option == 3)
            {
                
                longestWords();
                Console.ReadLine();
                callRun();
            }
            else if (option == 4)
            {        
                countTotalNumberofWords();
                Console.ReadLine();
                callRun();
            }

        }
        public string word { get; set; }
        public long frequency { get; set; }

        public long numberOfWords { get; set; }

        public long numberOfLines { get; set; }

        /// <summary>
        /// Returns number of lines in text
        /// </summary>
        public void countNumberoflines()
        {

            string fileName = @"mytestFile.txt";
            int count;
            try
            {
                

                using (StreamReader sr = File.OpenText(fileName))
                {
                    string s = "";
                    count = 0;
                    Console.WriteLine("Print the content of the file");
                    while ((s = sr.ReadLine()) != null)
                    {
                        
                        count++;
                    }

                    Console.WriteLine("The number of lines in the File {0} is :{1} \n", fileName, count);
                    Console.WriteLine("Please press Enter to Continue"); 
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }

        public void callRun()
        {
            IServiceCollection services = new ServiceCollection();

            Startup startup = new Startup();
            startup.ConfigureServices(services);

            IServiceProvider serviceProvider = services.BuildServiceProvider();

            // entry to run app
            serviceProvider.GetService<Runner>().Run();
        }

        /// <summary>
        /// Returns longestword.
        /// </summary>
        public void longestWords()
        {
            string maxword = "", stringlist = "";
            int n = 0, max = 0;
            string fileName = @"mytestFile.txt";

            string lines = File.ReadAllText(fileName);
            lines = lines.Replace("\r\n", "  ");
            foreach (char c in lines)
                    {
                        if (c == ' ')
                        {
                            if (n < max)
                            {
                                n = max;
                                max = 0;
                                maxword = stringlist;
                                stringlist = "";

                            }
                            else
                            {
                                max = 0;
                                stringlist = "";
                            }
                        }
                        else
                        {
                            stringlist = stringlist + c.ToString();
                            max++;
                        }
                        
                                       
                }
                Console.WriteLine(maxword);

            Console.WriteLine("Please press Enter to Continue");

        }


        /// <summary>
        /// Returns total number of words in text.
        /// </summary>
        public void countTotalNumberofWords()
        {

            int count = 1, len = 0;
            string fileName = @"mytestFile.txt";


            string lines = File.ReadAllText(fileName);

         
            while (len < lines.Length - 1)
                        {
                            if (lines[len] == ' ' || lines[len] == '\n' || lines[len] == '\t')
                            {
                                count++;
                            }
                            len++;

                        }
                    
                
            

            Console.WriteLine("Total no of words: " + count);
            Console.WriteLine("Please press Enter to Continue");
            Console.ReadLine();
        }

        /// <summary>
        /// Convenience method which prints the number of occurrences of each word in the given file
        /// </summary>
        public void topFrequentlistWords(int count)
        {
          
            Console.WriteLine("The number of counts for each words are: ");
            string fileName = @"mytestFile.txt";
           
            using (StreamReader sr = File.OpenText(fileName))
            {
                string s = "";
                IDictionary<string, int> counts= null;

                string lines = File.ReadAllText(fileName);
               
                    var words = SplitWords(lines);
                     counts = CountWordOccurrences(words,count);
                    WriteWordCounts(counts, count);
                
               
            }
        }

        /// <summary>
        /// Splits the given text into individual words, stripping punctuation
        /// A word is defined by the regex @"\p{L}+"
        /// </summary>
        public static IEnumerable<string> SplitWords(string text)
        {
            Regex wordMatcher = new Regex(@"\p{L}+");
            return wordMatcher.Matches(text).Select(c => c.Value);
        }

        /// <summary>
        /// Counts the number of occurrences of each word in the given enumerable
        /// </summary>
        public static IDictionary<string, int> CountWordOccurrences(IEnumerable<string> words,int count)
        {
            return CountOccurrences(words, StringComparer.CurrentCultureIgnoreCase, count);
        }

        /// <summary>
        /// Prints word-counts to the given TextWriter
        /// </summary>
        public static void WriteWordCounts(IDictionary<string, int> counts, int count)
        {
            IEnumerable<KeyValuePair<string, int>> mylist = counts.ToList();
            int flag = 0;
            mylist = mylist.OrderByDescending(x => x.Value);
            
            foreach (KeyValuePair<string, int> kvp in mylist)
            {
                flag++;
                Console.WriteLine("Counts: " + kvp.Value + "  " + kvp.Key.ToLower()); // print word in lower-case for consistency


                if (count == flag)
                {
                    Console.WriteLine("Please press Enter to Continue");
                    return;
                }
            }

        }


        /// <summary>
        /// Counts the number of occurrences of each distinct item
        /// </summary>
        public static IDictionary<T, int> CountOccurrences<T>(IEnumerable<T> items, IEqualityComparer<T> comparer,int count)
        {
            var counts = new Dictionary<T, int>(comparer);

            foreach (T t in items)
            {
                
                if (!counts.TryGetValue(t, out count))
                {
                    count = 0;
                }
                counts[t] = count + 1;
            }

            return counts;
        }
    }
}