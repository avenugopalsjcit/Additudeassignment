﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Additude_Assignment.Interfaces
{
    public interface IWordFrequency
    {
            /**
            * The word.
            * @return the word as a string.
*/
            String word { get; set; }
            /**
            * The frequency.
            * @return a long representing the frequency of the word.
*/
            long frequency { get; set; }       
    }
}
