﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Additude_Assignment.Interfaces
{
    public interface ITextStatistics
    {

        /**
* Returns a Number of lines in the text.
*/
        void countTotalNumberofWords();

        /**
* Returns a Number of lines in the text.
*/
        void countNumberoflines();

        /**
* Returns a list of the most frequented words of the text.
* @param n how many items of the list
* @return a list representing the top n frequent words of the text.
*/
        void topFrequentlistWords(int count);
        /**
        * Returns a list of the longest words of the text.
        * @param n how many items to return.
        * @return a list with the n longest words of the text.
*/

        void longestWords();
        /**
        * @return total number of words in the text.
*/
        long numberOfWords { get; }
        /**
        * @return total number of line of the text.
*/
        long numberOfLines { get; }
    }
}
