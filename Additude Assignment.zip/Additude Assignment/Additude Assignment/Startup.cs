using Additude_Assignment.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace Additude_Assignment
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IWordFrequency, Additude>();
            services.AddTransient<ITextStatistics, Additude>();
            services.AddTransient<Runner>();
        }
    }
}