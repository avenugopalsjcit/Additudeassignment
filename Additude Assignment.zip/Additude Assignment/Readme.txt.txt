Below is the file path in the project assignment which contains text for testing. Please feel free to replace 
the text in file with your own text.
C:\Users\avenu\Desktop\Additude\Additude Assignment\Additude Assignment\bin\Debug\net6.0\mytestFile.txt
IDE: Visual studio 2022.
It is .net core 6 Console application.
Run the application it guides for different outputs.

If the data is too large ofcourse we can use parallel programming concepts and many other best approaches.

I have written a simple logic for the problem statement in limited time frame i had. I was also working on other 
assignments and interviews telephonic,face to face and online. I tried my best to meet the requirements ofcourse 
based on time we can improve the coding standards. 


